import pywhatkit
from datetime import date, datetime, timedelta

pywhatkit.sendwhatmsg('+51969368883', 'Message 1', 23, 8)
