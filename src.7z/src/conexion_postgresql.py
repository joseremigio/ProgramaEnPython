#import psycopg2

#try:
#    connection=psycopg2.connect(
#        host='ec2-3-222-74-92.compute-1.amazonaws.com',
#        user='',
#        password='',
#        database=''
#    )

#    print("ok")
#except Exception as ex:
#    print(ex)
#finally:
#    connection.close()
