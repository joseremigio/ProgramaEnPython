from flask import Flask, render_template, request, redirect, url_for, flash, session
import logging
import config
import psycopg2
import psycopg2.extras
from decimal import Decimal
from flask_login import LoginManager, login_user, logout_user, login_required

#import pywhatkit

from datetime import date, datetime, timedelta

@login_required
def cajaApertura():
    fecha = datetime.now().strftime("%Y-%m-%d")
    return selectCajaApertura(fecha)

def selectCajaApertura (fechaSeleccionada):
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    scriptBanco = "SELECT ba.bancoid, ba.nombre, COALESCE((ca.montofinalreal), 0) AS montofinalreal, ca.fecha FROM banco ba "
    scriptBanco = scriptBanco + "left join caja ca on ca.bancoid =ba.bancoid "
    scriptBanco = scriptBanco + "order by ca.fecha desc, ba.orden "
    scriptBanco = scriptBanco + "limit (select count(bancoid) from banco ) "
    cur.execute(scriptBanco)  # Execute the SQL
    list_banco = cur.fetchall()
    Select = "SELECT c.cajaid, c.montoinicial, c.montofinalcalculado, c.montofinalreal, b.nombre from caja c left join banco b on b.bancoid =c.bancoid "
    Select = Select + "where c.fecha= '" + fechaSeleccionada + "'"
    Select = Select + " order by c.cajaid"
    cur.execute(Select)
    list_cajas = cur.fetchall()
    return render_template('cajaApertura.html', list_banco=list_banco, fecha=fechaSeleccionada, list_cajas=list_cajas)

@login_required
def cajaCierre():
    fecha = datetime.now().strftime("%Y-%m-%d")
    return selectCajaCierre(fecha)

def selectCajaCierre (fechaSeleccionada):
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    # Suma de caja Agente
    Select = "SELECT c.cajaid, c.montoinicial, c.montofinalcalculado, c.montofinalreal, b.nombre from caja c left join banco b on b.bancoid =c.bancoid "
    Select = Select + "where c.fecha= '" + fechaSeleccionada + "' and c.bancoid not in (15, 17)"
    Select = Select + " order by b.orden"
    cur.execute(Select)
    list_cajas = cur.fetchall()
    suma_caja = selectSumaDeCaja(fechaSeleccionada)

    #Suma de caja Wester union - Remesas
    select_wester = "SELECT c.cajaid, c.montoinicial, c.montofinalcalculado, c.montofinalreal, b.nombre from caja c left join banco b on b.bancoid =c.bancoid "
    select_wester = select_wester + "where c.fecha= '" + fechaSeleccionada + "' and c.bancoid in (15, 17)"
    select_wester = select_wester + " order by b.orden"
    cur.execute(select_wester)
    list_cajas_wester = cur.fetchall()
    suma_caja_wester = selectSumaDeCajaWester(fechaSeleccionada)

    #Suma de efectivo total soles
    select_efectivo_total_sol = "SELECT sum (c.montoinicial) as sumamontoinicial , sum (c.montofinalcalculado) as sumamontofinalcalculado, sum (c.montofinalreal) as sumamontofinalreal from caja c "
    select_efectivo_total_sol = select_efectivo_total_sol + "where c.fecha= '" + fechaSeleccionada + "' and c.bancoid  in (7, 15, 19)"
    select_efectivo_total_sol = select_efectivo_total_sol + " group by c.fecha"
    cur.execute(select_efectivo_total_sol)
    list_efectivo_total_sol = cur.fetchall()

    # Suma de efectivo total dolares
    select_efectivo_total_dolares = "SELECT sum (c.montoinicial) as sumamontoinicial , sum (c.montofinalcalculado) as sumamontofinalcalculado, sum (c.montofinalreal) as sumamontofinalreal from caja c "
    select_efectivo_total_dolares = select_efectivo_total_dolares + "where c.fecha= '" + fechaSeleccionada + "' and c.bancoid  in (16, 17, 18)"
    select_efectivo_total_dolares = select_efectivo_total_dolares + " group by c.fecha"
    cur.execute(select_efectivo_total_dolares)
    list_efectivo_total_dolares = cur.fetchall()

    return render_template('cajaCierre.html', list_cajas=list_cajas, fecha=fechaSeleccionada, suma_caja=suma_caja, list_cajas_wester=list_cajas_wester, suma_caja_wester=suma_caja_wester, list_efectivo_total_sol=list_efectivo_total_sol, list_efectivo_total_dolares=list_efectivo_total_dolares)

def selectSumaDeCaja (fechaSeleccionada):
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    Select = "SELECT sum(c.montoinicial) as sumamontoinicial , sum(c.montofinalcalculado) as sumamontofinalcalculado, sum(c.montofinalreal) as sumamontofinalreal from caja c  "
    Select = Select + "where c.bancoid not in (15, 17) and c.fecha= '" + fechaSeleccionada + "'"
    Select = Select + " group by c.fecha"
    cur.execute(Select)
    suma_caja = cur.fetchall()
    try:
        utilidad = suma_caja[0][2] - obtenerCapital()[0][0]
        suma_caja.insert(3,[utilidad])
    finally:
        return suma_caja

def selectSumaDeCajaWester (fechaSeleccionada):
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    Select = "SELECT sum(c.montoinicial) as sumamontoinicial , sum(c.montofinalcalculado) as sumamontofinalcalculado, sum(c.montofinalreal) as sumamontofinalreal from caja c  "
    Select = Select + "where c.bancoid  in (15, 17) and c.fecha= '" + fechaSeleccionada + "'"
    Select = Select + " group by c.fecha"
    cur.execute(Select)
    suma_caja = cur.fetchall()
    try:
        utilidad = suma_caja[0][2] - obtenerCapital()[0][0]
        suma_caja.insert(3,[utilidad])
    finally:
        return suma_caja

@login_required
def add_cajaApertura():
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    if request.method == 'POST':
        if request.form['accion_btn'] == 'registrar':  # registrar
            Fecha = request.form['fecha']
            Select = "SELECT count(cajaid) from caja where fecha= '" + Fecha + "'"
            cur.execute(Select)
            list_caja = cur.fetchall()
            if int(list_caja[0][0]) > 0:
                flash('Ya se tiene aperturada caja para la fecha:' + Fecha, 'error')
                return redirect(url_for('cajaApertura'))

            for item in request.form:
                if item.isnumeric():
                    MontoInicial = request.form[item]
                    BancoId = int(item)
                    Insert = "INSERT INTO caja (cajaid, bancoid, montoinicial, fecha, montofinalcalculado, montofinalreal) VALUES (nextval('caja_sq'),%s,%s,%s,%s,0)"
                    cur.execute(Insert, (BancoId, MontoInicial, Fecha, MontoInicial))
                    conn.commit()
            flash('Apertura de caja  conexito con fecha: ' + Fecha, 'success')
            return redirect(url_for('cajaApertura'))
        if request.form['accion_btn'] == 'buscar':  # registrar
            return selectCajaApertura(request.form['fecha'])
        else:
            Fecha = request.form['fecha']
            Delete = "DELETE FROM caja WHERE fecha = '" + Fecha + "'"
            cur.execute(Delete)
            conn.commit()
            Delete = "DELETE FROM operaciones WHERE fechaoperacion between %s and  %s "
            cur.execute(Delete, (Fecha, Fecha + " 23:59:59"))
            conn.commit()
            flash('Se elimino con exito la caja y operaciones de la fecha: ' + Fecha, 'success')
            return selectCajaApertura(Fecha)

@login_required
def add_cajaCierre():
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    if request.method == 'POST':
        if request.form['accion_btn']=='actualizar': #actualizar
            for item in request.form:
                if item.isnumeric():
                    MontoFinalReal = request.form[item]
                    CajaId = int(item)
                    Update = "UPDATE caja SET montofinalreal=%s where cajaid=%s"
                    cur.execute(Update,(MontoFinalReal, CajaId))
                    conn.commit()
            flash('Cierre de caja con exito.', 'success')
            #pywhatkit.sendwhatmsg('+51969368883', 'Message 2', datetime.now().hour, datetime.now().minute + 1)
            return redirect(url_for('cajaCierre'))
        else: #buscar
            return selectCajaCierre(request.form['fechaCierre'])

def actualizarCajaBanco (TipoOperacionId, BancoId, Monto, Comision, TipoMonedaId):
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    Fecha = str(datetime.now().strftime("%Y-%m-%d"))
    Select = "SELECT cajaid, bancoid, montoinicial, montofinalreal, fecha, montofinalcalculado, estado  from caja"
    Select = Select + " where fecha= '" + Fecha + "'" + " and bancoid=" + str(BancoId)
    cur.execute(Select)
    caja = cur.fetchall()

    CajaId = caja[0][0]
    Montoinicial = caja[0][2]
    Montofinalcalculado = caja[0][5]
    if int(TipoOperacionId) == 1:  #salida de efectivo
        NuevoMontofinalcalculadoBanco = Montofinalcalculado + Monto
    else: #ingreso de efectivo
        NuevoMontofinalcalculadoBanco = Montofinalcalculado - Monto

    Update = "UPDATE caja SET montofinalcalculado=%s where cajaid=%s"
    cur.execute(Update, (NuevoMontofinalcalculadoBanco, CajaId))
    conn.commit()

    actualizarEfectivoCaja(Monto, Comision, TipoOperacionId)

    return NuevoMontofinalcalculadoBanco

def actualizarCajaBancoWesterunion (TipoOperacionId, BancoId, Monto, Comision, TipoMonedaId):
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    Fecha = str(datetime.now().strftime("%Y-%m-%d"))
    Select = "SELECT cajaid, bancoid, montoinicial, montofinalreal, fecha, montofinalcalculado, estado  from caja"
    Select = Select + " where fecha= '" + Fecha + "'" + " and bancoid=" + str(BancoId)
    cur.execute(Select)
    caja = cur.fetchall()
    CajaId = caja[0][0]
    Montoinicial = caja[0][2]
    Montofinalcalculado = caja[0][5]

    if int(TipoOperacionId) == 1:  # salida de efectivo
        NuevoMontofinalcalculadoBanco = Montofinalcalculado - Monto
    else:  # ingreso de efectivo
        NuevoMontofinalcalculadoBanco = Montofinalcalculado + Monto

    Update = "UPDATE caja SET montofinalcalculado=%s where cajaid=%s"
    cur.execute(Update, (NuevoMontofinalcalculadoBanco, CajaId))
    conn.commit()
    return NuevoMontofinalcalculadoBanco

def actualizarEfectivoCaja (Monto, Comision, TipoOperacionId):
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    Fecha = str(datetime.now().strftime("%Y-%m-%d"))

    if session['rolid'] == 2:
        cajaEfectivo = 19 #caja secundario
    else:
        cajaEfectivo = 7 #caja principal

    Select = "SELECT cajaid, bancoid, montoinicial, montofinalreal, fecha, montofinalcalculado, estado  from caja"
    Select = Select + " where fecha= '" + Fecha + "'" + " and bancoid=" + str(cajaEfectivo)
    cur.execute(Select)
    caja = cur.fetchall()
    CajaId = caja[0][0]
    Montoinicial = caja[0][2]
    Montofinalcalculado = caja[0][5]

    if int(TipoOperacionId) == 1:  # salida de efectivo
        NuevoMontofinalcalculado = Montofinalcalculado - Monto + Comision

    else:  # ingreso de efectivo
        NuevoMontofinalcalculado = Montofinalcalculado + Monto + Comision

    Update = "UPDATE caja SET montofinalcalculado=%s where cajaid=%s"
    cur.execute(Update, (NuevoMontofinalcalculado, CajaId))
    conn.commit()

def ajustaCajaEfectivo (Monto, Comision, TipoOperacionId, BancoId):
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    Fecha = str(datetime.now().strftime("%Y-%m-%d"))
    #rollback del banco
    if (int(BancoId) != 15 and int(BancoId) != 17):
        Select = "SELECT cajaid, bancoid, montoinicial, montofinalreal, fecha, montofinalcalculado, estado  from caja"
        Select = Select + " where fecha= '" + Fecha + "'" + " and bancoid=" + str(BancoId)
        cur.execute(Select)
        caja = cur.fetchall()

        CajaId = caja[0][0]
        Montoinicial = caja[0][2]
        Montofinalcalculado = caja[0][5]

        if int(TipoOperacionId) == 1:  # salida de efectivo
            NuevoMontofinalcalculadoBanco = Montofinalcalculado - float(Monto)

        else:  # ingreso de efectivo
            NuevoMontofinalcalculadoBanco = Montofinalcalculado + float(Monto)

        Update = "UPDATE caja SET montofinalcalculado=%s where cajaid=%s"
        cur.execute(Update, (NuevoMontofinalcalculadoBanco, CajaId))
        conn.commit()

    # rollback del efectivo
    # Si no es una operacion Wester Remesa, se actualiza la caja de EFECTIVO - AGENTE
    if (int(BancoId) != 15 and int(BancoId) != 17):
        if session['rolid'] == 2:
            BancoIdCajaEfectivo = 19  # caja secundario
        else:
            BancoIdCajaEfectivo = 7  # caja principal

    # Si es una operacion de WESTER Remesa, se actualiza la caja de Wester Remesa.
    else:
        BancoIdCajaEfectivo = BancoId

    Select = "SELECT cajaid, bancoid, montoinicial, montofinalreal, fecha, montofinalcalculado, estado  from caja"
    Select = Select + " where fecha= '" + Fecha + "'" + " and bancoid="+str(BancoIdCajaEfectivo)
    cur.execute(Select)
    caja = cur.fetchall()
    CajaId = caja[0][0]
    Montofinalcalculado = caja[0][5]

    if int(TipoOperacionId) == 1:  # salida de efectivo
        NuevoMontofinalcalculado = Montofinalcalculado + float(Monto) - float(Comision)

    else:  # ingreso de efectivo
        NuevoMontofinalcalculado = Montofinalcalculado - float(Monto) - float(Comision)

    Update = "UPDATE caja SET montofinalcalculado=%s where cajaid=%s"
    cur.execute(Update, (NuevoMontofinalcalculado, CajaId))
    conn.commit()

def obtenerCapital():
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    Select = "SELECT sum(monto) from capital  where tipo like  'EFECTIVO%'"
    cur.execute(Select)
    list_capital = cur.fetchall()
    return list_capital

def actualizarCajaDolar(TipoOperacionId, BancoId, Monto, TipoCambio, TipoMonedaId, esRegistro):
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    Fecha = str(datetime.now().strftime("%Y-%m-%d"))
    Select = "SELECT cajaid, bancoid, montoinicial, montofinalreal, fecha, montofinalcalculado, estado  from caja"
    Select = Select + " where fecha= '" + Fecha + "'" + " and bancoid=" + str(BancoId)
    cur.execute(Select)
    caja = cur.fetchall()

    CajaId = caja[0][0]
    Montoinicial = caja[0][2]
    Montofinalcalculado = caja[0][5]

    if esRegistro: #registro
        if int(TipoOperacionId) == 1:  #salida de efectivo
            NuevoMontofinalcalculadoBanco = Decimal(Montofinalcalculado) + Decimal(Monto)
        else: #ingreso de efectivo
            NuevoMontofinalcalculadoBanco = Decimal(Montofinalcalculado) - (Decimal(Monto)/Decimal(TipoCambio))
    else: #eliminar
        if int(TipoOperacionId) == 1:  #salida de efectivo
            NuevoMontofinalcalculadoBanco = Decimal(Montofinalcalculado) - Decimal(Monto)
        else: #ingreso de efectivo
            NuevoMontofinalcalculadoBanco = Decimal(Montofinalcalculado) + (Decimal(Monto)/Decimal(TipoCambio))

    Update = "UPDATE caja SET montofinalcalculado=%s where cajaid=%s"
    cur.execute(Update, (NuevoMontofinalcalculadoBanco, CajaId))
    conn.commit()

    actualizarEfectivoCajaDolar(Monto, TipoCambio, TipoOperacionId,esRegistro)

    return NuevoMontofinalcalculadoBanco

def actualizarEfectivoCajaDolar (Monto, TipoCambio, TipoOperacionId,esRegistro):
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    if session['rolid'] == 2:
        BancoIdCajaEfectivo = 19  # caja secundario
    else:
        BancoIdCajaEfectivo = 7  # caja principal

    Fecha = str(datetime.now().strftime("%Y-%m-%d"))
    Select = "SELECT cajaid, bancoid, montoinicial, montofinalreal, fecha, montofinalcalculado, estado  from caja"
    Select = Select + " where fecha= '" + Fecha + "'" + " and bancoid=" + str(BancoIdCajaEfectivo)
    cur.execute(Select)
    caja = cur.fetchall()
    CajaId = caja[0][0]
    Montoinicial = caja[0][2]
    Montofinalcalculado = caja[0][5]

    if esRegistro:  # registro
        if int(TipoOperacionId) == 1:  # salida de efectivo
            NuevoMontofinalcalculado = Decimal(Montofinalcalculado) - (Decimal(Monto)*Decimal(TipoCambio))
        else:  # ingreso de efectivo
            NuevoMontofinalcalculado = Decimal(Montofinalcalculado) + Decimal(Monto)
    else:  # eliminar
        if int(TipoOperacionId) == 1:  # salida de efectivo
            NuevoMontofinalcalculado = Decimal(Montofinalcalculado) + (Decimal(Monto)*Decimal(TipoCambio))
        else:  # ingreso de efectivo
            NuevoMontofinalcalculado = Decimal(Montofinalcalculado) - Decimal(Monto)

    Update = "UPDATE caja SET montofinalcalculado=%s where cajaid=%s"
    cur.execute(Update, (NuevoMontofinalcalculado, CajaId))
    conn.commit()