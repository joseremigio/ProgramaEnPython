from flask import Flask, render_template, request, redirect, url_for, flash, session
from datetime import date, datetime, timedelta
import logging
from flask_wtf.csrf import CSRFProtect
from flask_login import LoginManager, login_user, logout_user, login_required
import psycopg2.extras
# Models:
from models.ModelUser import ModelUser

# Entities:
from models.entities.User import User
import operaciones
import caja
import capital
import config

app = Flask(__name__)
app.add_url_rule('/operacion', view_func=operaciones.pago)
app.add_url_rule('/nuevaOperacionWesterUnion', view_func=operaciones.nuevaOperacionWesterUnion, methods=['POST', 'GET'])
app.add_url_rule('/add_operacion', view_func=operaciones.add_operacion, methods=['POST'])
app.add_url_rule('/delete/<string:id>/<string:monto>/<string:comision>/<string:tipoOperacionId>/<string:bancoId>', view_func=operaciones.delete_operacion, methods=['GET'])
app.add_url_rule('/transferir', view_func=operaciones.transferir, methods=['POST', 'GET'])
app.add_url_rule('/compraventadolar', view_func=operaciones.compraventadolar, methods=['POST', 'GET'])

app.add_url_rule('/cajaApertura', view_func=caja.cajaApertura)
app.add_url_rule('/cajaCierre', view_func=caja.cajaCierre)
app.add_url_rule('/add_cajaApertura', view_func=caja.add_cajaApertura, methods=['POST'])
app.add_url_rule('/add_cajaCierre', view_func=caja.add_cajaCierre, methods=['POST'])

app.add_url_rule('/capital', view_func=capital.capital)
app.add_url_rule('/add_capital', view_func=capital.add_capital, methods=['POST'])


app.logger.setLevel(logging.ERROR)

app.secret_key = "cairocoders-ednalan"

csrf = CSRFProtect()
login_manager_app = LoginManager(app)

@login_manager_app.user_loader
def load_user(id):
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    #cur = config.get_db_connection()
    return ModelUser.get_by_id(cur, id)

@app.route('/', methods=['GET', 'POST'])
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    if request.method == 'POST':
        user = User(0, request.form['username'], request.form['password'])
        logged_user = ModelUser.login(cur, user)
        if logged_user != None:
            if logged_user.password:
                login_user(logged_user)
                session['nombre'] = logged_user.username
                session['rolid'] = logged_user.rolid
                session['usuarioid'] = logged_user.id
                return redirect(url_for('home'))
            else:
                flash("Contraseña invalida")
                return render_template('login.html')
        else:
            flash("Usuario no encontrado")
            return render_template('login.html')
    else:
        return render_template('login.html')

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/home', methods=['GET', 'POST'])
@login_required
def home():
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    fechaActual = datetime.now().strftime("%Y-%m-%d")
    RecargaSaldo = True
    if request.method == 'POST':
        fechaInicio = request.form['startDate']
        fechaFin = request.form['endDate']
        BancoId = request.form['BancoId']
        TipoOperacionId = request.form['TipoOperacionId']
        try:
            RecargaSaldo = request.form.get("recargaSaldo") != None
        finally:
            RecargaSaldo = RecargaSaldo
        s = "SELECT op.operacionid, top.nombre, op.monto, op.comision, op.fechaoperacion, op.comentario, tm.nombre, b.nombre, op.comentario, op.saldo, top.tipooperacionid, op.bancoid, ROW_NUMBER () OVER(ORDER BY operacionid DESC) as indice, usu.nombre, usu.usuarioid, op.numerooperacion FROM operaciones as op left  join  tipomoneda tm on tm.tipomonedaid = op.tipomonedaid left join tipooperacion top on top.tipooperacionid = op.tipooperacionid  left join banco b on b.bancoid =op.bancoid left join usuario usu on usu.usuarioid =op.usuarioid "
        s = s + "where op.fechaoperacion between %s and  %s "
        SelectSumaComision = "SELECT sum(comision), sum(numerooperacion) FROM operaciones where fechaoperacion between %s and  %s"
        if BancoId=='0':
            SelectSumaComision = SelectSumaComision
        else:
            s = s + " and b.bancoid= " + str(BancoId)
            SelectSumaComision = SelectSumaComision + " and bancoid=" + BancoId

        if TipoOperacionId=='0':
            SelectSumaComision = SelectSumaComision
        else:
            s = s + " and op.tipooperacionid= " + str(TipoOperacionId)
            SelectSumaComision = SelectSumaComision + " and tipooperacionid=" + TipoOperacionId

        if RecargaSaldo:
            s = s + " and op.comentario!='RECARGA SALDO'"

        if session['rolid']==2:
            s = s + " and op.usuarioid=" + str(session['usuarioid'])

        s = s + "order by op.operacionid DESC "
        cur.execute(s, (fechaInicio, fechaFin + " 23:59:59"))

    else:
        fechaInicio=datetime.now().strftime("%Y-%m-%d")
        #fechaFin=(date.today() + timedelta(days=1)).strftime("%Y-%m-%d")
        fechaFin = fechaInicio
        s = "SELECT op.operacionid, top.nombre, op.monto, op.comision, op.fechaoperacion, op.comentario, tm.nombre, b.nombre, op.comentario, op.saldo, top.tipooperacionid, op.bancoid, ROW_NUMBER () OVER(ORDER BY operacionid DESC) as indice, usu.nombre, usu.usuarioid, op.numerooperacion FROM operaciones as op left  join  tipomoneda tm on tm.tipomonedaid = op.tipomonedaid left join tipooperacion top on top.tipooperacionid = op.tipooperacionid left join banco b on b.bancoid =op.bancoid left join usuario usu on usu.usuarioid =op.usuarioid "
        s = s + "where op.fechaoperacion between %s and  %s "
        s = s + " and op.comentario!='RECARGA SALDO'"

        if session['rolid']==2:
            s = s + " and op.usuarioid=" + str(session['usuarioid'])

        s = s + "order by op.operacionid DESC "
        cur.execute(s, (fechaInicio, fechaFin + " 23:59:59"))
        BancoId = '0'
        TipoOperacionId = '0'
        SelectSumaComision = "SELECT sum(comision), sum(numerooperacion) FROM operaciones where fechaoperacion between %s and  %s"

    list_operaciones = cur.fetchall()

    scriptBanco = "SELECT bancoid, nombre FROM banco order by bancoid"
    cur.execute(scriptBanco)
    list_banco = cur.fetchall()
    list_banco.insert(0, [0, "TODOS"])

    scriptTipoOperacion = "SELECT tipooperacionid, nombre FROM tipooperacion order by tipooperacionid"
    cur.execute(scriptTipoOperacion)  # Execute the SQL
    list_tipooperaciones = cur.fetchall()
    list_tipooperaciones.insert(0, [0, "TODOS"])

    cur.execute(SelectSumaComision, (fechaInicio, fechaFin + " 23:59:59"))
    sumaComision = cur.fetchall()

    return render_template('index.html', list_operaciones=list_operaciones, list_banco=list_banco, fechaInicio=fechaInicio, fechaFin=fechaFin, bancoSelectedId=BancoId, tipoOperacionSelectedId=TipoOperacionId,fechaActual=fechaActual, sumaComision=sumaComision, list_tipooperaciones=list_tipooperaciones,recargaSaldo=RecargaSaldo)

@app.route('/reporte/<string:anio>/<string:mes>')
@login_required
def reporte(anio, mes):
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    Select = "select sum(montoinicial) as montoinicial, sum(montofinalcalculado) as montofinalcalculado, sum(montofinalreal) as montofinalreal, fecha, EXTRACT(year from fecha) as anio, EXTRACT(month from fecha) as mes, EXTRACT(day from fecha) as dia  from  caja "
    Select = Select + " where EXTRACT(year from fecha)=" + anio + " and EXTRACT(month from fecha)=" + mes
    Select = Select + " group by fecha order by dia"
    cur.execute(Select)  # Execute the SQL
    list_cajas = cur.fetchall()

    montosiniciales = []
    montosfinalcalculados = []
    montosfinalreales = []
    fechas = []
    meses = []
    dias = []

    posicion = 1
    for item in list_cajas:
        montosiniciales.insert(posicion, item[0])
        montosfinalcalculados.insert(posicion, item[1])
        montosfinalreales.insert(posicion, item[2])
        fechas.insert(posicion, item[3])
        meses.insert(posicion, item[5])
        dias.insert(posicion, item[6])
        posicion = posicion+1
    return render_template('reporte.html', dias=dias , montosiniciales=montosiniciales, montosfinalcalculados=montosfinalcalculados, montosfinalreales=montosfinalreales, list_cajas=list_cajas)

if __name__ == '__main__':
    app.run()
    #app.run(host='0.0.0.0', port=8000, debug=True) #para acceder desde la misma red mediante la IP
