from .entities.User import User


class ModelUser():

    @classmethod
    def login(self, db, user):
        try:
            sql = """SELECT usuarioid, nombre, contrasena, rolid FROM usuario 
                    WHERE nombre = '{}'""".format(user.username)
            db.execute(sql)
            row = db.fetchone()

            if row != None:
                user = User(row[0], row[1], User.check_password(row[2], user.password), row[3], row[3])
                return user
            else:
                return None
        except Exception as ex:
            raise Exception(ex)

    @classmethod
    def get_by_id(self, db, id):
        try:
            sql = "SELECT usuarioid, nombre, contrasena, rolid FROM usuario WHERE usuarioid = {}".format(id)
            db.execute(sql)
            row = db.fetchone()
            if row != None:
                return User(row[0], row[1], None, row[2], row[3])
            else:
                return None
        except Exception as ex:
            raise Exception(ex)
