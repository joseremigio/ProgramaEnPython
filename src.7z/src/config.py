import psycopg2

def get_db_connection():
    bdRemote = False
    if (bdRemote):
        DB_HOST = "localhost"
        DB_NAME = "agente"
        DB_USER = "agenteuser"
        DB_PASS = "postgres"
    else:
        DB_HOST = "localhost"
        DB_NAME = "agente"
        DB_USER = "postgres"
        DB_PASS = "postgres"

    conn = psycopg2.connect(dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST)
    #conn = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)

    return conn