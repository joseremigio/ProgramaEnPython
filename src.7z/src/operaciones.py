from flask import Flask, render_template, request, redirect, url_for, flash, session
import logging
import config
import psycopg2.extras
#import win32ui
#import win32print
#import win32con
from flask_login import LoginManager, login_user, logout_user, login_required
from datetime import date, datetime, timedelta
from caja import actualizarCajaBanco, ajustaCajaEfectivo, actualizarCajaBancoWesterunion, actualizarCajaDolar
#from reportlab.pdfgen import canvas


@login_required
def pago():
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    s = "SELECT tipooperacionid, nombre FROM tipooperacion order by tipooperacionid"
    cur.execute(s)  # Execute the SQL
    list_tipooperaciones = cur.fetchall()
    sBanco = "SELECT bancoid, nombre, estilocss FROM banco where bancoid NOT IN (7,10,15,16,17,18,19) order by orden"
    cur.execute(sBanco)  # Execute the SQL
    list_banco= cur.fetchall()
    #conn.close()  # cierre de conexion
    return render_template('operacion.html', list_tipooperaciones=list_tipooperaciones, list_banco=list_banco)

@login_required
def nuevaOperacionWesterUnion():
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    if request.method == 'POST':
        Fecha = str(datetime.now().strftime("%Y-%m-%d"))
        Select = "SELECT count(cajaid) from caja where fecha= '" + Fecha + "'"
        cur.execute(Select)
        list_operacion = cur.fetchall()
        if int(list_operacion[0][0]) == 0:
            flash('No se tiene aperturada caja para la fecha:' + Fecha, 'error')
            return redirect(url_for('nuevaOperacionWesterUnion'))
        TipoOperacionId = int(request.form['TipoOperacionId'])
        Monto = float(request.form['Monto'])
        Comision = 0
        FechaOperacion = datetime.now()
        Comentario = request.form['Comentario']
        TipoMonedaId = int(request.form['TipoMoneda'])
        BancoId = int(request.form['BancoId'])
        Saldo = actualizarCajaBancoWesterunion(TipoOperacionId, BancoId, Monto, Comision, TipoMonedaId)
        bancoNombreYtipoOperacionNombre = request.form['bancoNombreYtipoOperacionNombre']
        cur.execute(
            "INSERT INTO operaciones (operacionid, tipooperacionid, monto, comision, fechaoperacion, comentario, tipomonedaid, bancoid, saldo) VALUES (nextval('opreaciones_sq'),%s,%s,%s,%s,%s,%s,%s,%s)",
            (TipoOperacionId, Monto, Comision, FechaOperacion, Comentario, TipoMonedaId, BancoId, Saldo))
        conn.commit()
        flash('Operacion registrada con exito.' + 'Operacion: ' + bancoNombreYtipoOperacionNombre + " Monto:" +
              request.form['Monto'], 'success')

        return redirect(url_for('nuevaOperacionWesterUnion'))
    else:
        queryTipoOperacion = "SELECT tipooperacionid, nombre FROM tipooperacion order by tipooperacionid"
        cur.execute(queryTipoOperacion)
        list_tipooperaciones = cur.fetchall()
        queryBanco = "SELECT bancoid, nombre FROM banco where bancoid IN (15,17) order by orden"
        cur.execute(queryBanco)
        list_banco = cur.fetchall()
        return render_template('NuevaOperacionWesterUnion.html', list_tipooperaciones=list_tipooperaciones,list_banco=list_banco)

@login_required
def add_operacion():
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    Fecha = str(datetime.now().strftime("%Y-%m-%d"))
    Select = "SELECT count(cajaid) from caja where fecha= '" + Fecha + "'"
    cur.execute(Select)
    list_operacion = cur.fetchall()
    if int(list_operacion[0][0]) == 0:
        flash('No se tiene aperturada caja para la fecha:' + Fecha, 'error')
        return redirect(url_for('pago'))

    if request.method == 'POST':
        TipoOperacionId = int(request.form['TipoOperacionId'])
        Monto = float(request.form['Monto'])
        Comision = 0
        try:
            Comision = float(request.form['Comision'])
        finally:
            Comision=Comision
        FechaOperacion = datetime.now()
        Comentario = request.form['Comentario']
        numerooperacion = request.form['numerooperacion']
        TipoMonedaId = int(request.form['TipoMoneda'])
        BancoId = int(request.form['BancoId'])
        Saldo = actualizarCajaBanco(TipoOperacionId, BancoId, Monto, Comision, TipoMonedaId)
        bancoNombreYtipoOperacionNombre = request.form['bancoNombreYtipoOperacionNombre']
        cur.execute("INSERT INTO operaciones (operacionid, tipooperacionid, monto, comision, fechaoperacion, comentario, tipomonedaid, bancoid, saldo, usuarioid, numerooperacion) VALUES (nextval('opreaciones_sq'),%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", (TipoOperacionId, Monto, Comision, FechaOperacion, Comentario, TipoMonedaId,BancoId, Saldo, session['usuarioid'], numerooperacion))
        conn.commit()
        flash('Operacion registrada con exito.' + 'Operacion: ' + bancoNombreYtipoOperacionNombre + " Monto:" + request.form['Monto'] +", Comision:" + request.form['Comision'], 'success')

        #c = canvas.Canvas("hola-mundo.pdf")
        #c.save()
        #c.drawString(50, 50, "¡Hola, mundo!")

        return redirect(url_for('pago'))

@login_required
def delete_operacion(id, monto, comision, tipoOperacionId, bancoId):
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    if (bancoId=='16'  or bancoId=='18'): #rollbackCompraVentaDolar
        Select = "SELECT tipocambio, tipooperacionid, bancoid, tipomonedaid from operaciones where operacionid= '" + id + "'"
        cur.execute(Select)
        list_operacion = cur.fetchall()
        tipoCambio = list_operacion[0][0]
        tipooperacionid = list_operacion[0][1]
        bancoDestinoId = list_operacion[0][2]
        tipoMonedaId = list_operacion[0][3]
        esRegistro = False
        saldo = actualizarCajaDolar(tipooperacionid, bancoDestinoId, monto, tipoCambio, tipoMonedaId, esRegistro)
    else:
        ajustaCajaEfectivo(monto, comision, tipoOperacionId, bancoId)
    cur.execute('DELETE FROM operaciones WHERE operacionid = {0}'.format(id))
    conn.commit()
    flash('Operacion eliminada con exito')
    return redirect(url_for('home'))

@login_required
def transferir():
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    if request.method == 'POST':

        Fecha = str(datetime.now().strftime("%Y-%m-%d"))
        Select = "SELECT count(cajaid) from caja where fecha= '" + Fecha + "'"
        cur.execute(Select)
        list_operacion = cur.fetchall()
        if int(list_operacion[0][0]) == 0:
            flash('No se tiene aperturada caja para la fecha:' + Fecha, 'error')
            return redirect(url_for('transferir'))

        Monto = float(request.form['Monto'])
        FechaOperacion = datetime.now()
        Comentario = "RECARGA SALDO"
        TipoMonedaId = int(request.form['TipoMoneda'])
        BancoOrigenId = int(request.form['BancoOrigenId'])
        BancoDestinoId = int(request.form['BancoDestinoId'])
        Saldo = actualizarCajaBanco(2, BancoOrigenId, Monto, 0, TipoMonedaId)
        cur.execute(
            "INSERT INTO operaciones (operacionid, tipooperacionid, monto, comision, fechaoperacion, comentario, tipomonedaid, bancoid, saldo, usuarioid, numerooperacion) VALUES (nextval('opreaciones_sq'),%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (2, Monto, 0, FechaOperacion, Comentario, TipoMonedaId, BancoOrigenId, Saldo, session['usuarioid'], 0))
        conn.commit()

        Saldo = actualizarCajaBanco(1, BancoDestinoId, Monto, 0, TipoMonedaId)
        cur.execute(
            "INSERT INTO operaciones (operacionid, tipooperacionid, monto, comision, fechaoperacion, comentario, tipomonedaid, bancoid, saldo, usuarioid, numerooperacion) VALUES (nextval('opreaciones_sq'),%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (1, Monto, 0, FechaOperacion, Comentario, TipoMonedaId, BancoDestinoId, Saldo, session['usuarioid'], 0))
        conn.commit()
        flash('Transferencia registrada con exito.','success')
        return redirect(url_for('transferir'))
    else:
        sBanco = "SELECT bancoid, nombre FROM banco where bancoid NOT IN (7,16, 18, 19, 15, 17, 10) order by orden"
        cur.execute(sBanco)  # Execute the SQL
        list_banco= cur.fetchall()
        #conn.close()  # cierre de conexion
        return render_template('transferir.html', list_banco=list_banco)

@login_required
def compraventadolar():
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    if request.method == 'POST':
        Fecha = str(datetime.now().strftime("%Y-%m-%d"))
        Select = "SELECT count(cajaid) from caja where fecha= '" + Fecha + "'"
        cur.execute(Select)
        list_operacion = cur.fetchall()
        if int(list_operacion[0][0]) == 0:
            flash('No se tiene aperturada caja para la fecha:' + Fecha, 'error')
            return redirect(url_for('compraventadolar'))

        monto = request.form['enviar']
        valor_compra = request.form['valor_compra']
        valor_venta = request.form['valor_venta']

        if float(valor_compra) < 1:
            flash('No se tiene registrado el tipo de Compra.', 'error')
            return redirect(url_for('compraventadolar'))

        if float(valor_venta) < 1:
            flash('No se tiene registrado el tipo de Venta.', 'error')
            return redirect(url_for('compraventadolar'))

        fechaOperacion = datetime.now()
        cambioValor = request.form['cambioValor']
        #tipoMonedaId = int(request.form['TipoMonedaId'])
        descripcion = request.form['Descripcion']

        if session['rolid'] == 2:
            bancoDestinoId = 18  # EFECTIVO - DOLARES # Caja Secundaria
        else:
            bancoDestinoId = 16  # EFECTIVO - DOLARES # Caja Principal

        if cambioValor=="Soles":
            tipooperacionid = 2  # Ingreso de efecto S./ por que se vende dolares e ingresa soles.
            tipoCambio = valor_venta
            tipoMonedaId = 1 # Tipo de Moneda que ingresa S/
            textoValor = "Venta: "
        else:
            tipooperacionid = 1  # Retiro de efectivo S./  por que se compra dolares
            tipoCambio = valor_compra
            tipoMonedaId= 2 # Tipo de Moneda que ingresa $
            textoValor = "Compra: "

        esRegistro = True
        saldo = actualizarCajaDolar(tipooperacionid, bancoDestinoId, monto, tipoCambio, tipoMonedaId, esRegistro)

        cur.execute(
            "INSERT INTO operaciones (operacionid, tipooperacionid, monto, fechaoperacion, comentario, tipomonedaid, bancoid, saldo, tipocambio, comision, usuarioid, numerooperacion) VALUES (nextval('opreaciones_sq'),%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (tipooperacionid, monto, fechaOperacion, textoValor + str(tipoCambio) +". " +descripcion, tipoMonedaId, bancoDestinoId, saldo, tipoCambio,0,session['usuarioid'],1))
        conn.commit()
        flash('Transferencia registrada con exito.' + ' Moneda:' + str(cambioValor) + ' Tipo de Cambio:' + str(tipoCambio) + ' Monto:' + str(monto),'success')
        insertarTipoCambio(valor_venta, valor_compra, Fecha)
        #imprimirventa(valor_venta, valor_compra, Fecha)
        return render_template('compraventadolar.html', valor_venta=valor_venta, valor_compra=valor_compra)
    else:
        Fecha = str(datetime.now().strftime("%Y-%m-%d"))
        Select = "SELECT tipocambioid, valorcompra, valorventa, fecha, estado FROM  tipocambio order by tipocambioid desc limit 1"
        cur.execute(Select)
        list_tipo_cambio = cur.fetchall()
        if len(list_tipo_cambio)==0:
            valor_compra=0.000
            valor_venta =0.000
        else:
            valor_compra = list_tipo_cambio[0][1]
            valor_venta = list_tipo_cambio[0][2]
        return render_template('compraventadolar.html', valor_venta=valor_venta, valor_compra=valor_compra)

def insertarTipoCambio(valor_venta, valor_compra, Fecha):
    conn = config.get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    cur.execute(
        "INSERT INTO tipocambio (tipocambioid, valorcompra, valorventa, fecha) VALUES (nextval('tipocambio_sq'),%s ,%s, %s)",
        (valor_compra,valor_venta, Fecha))
    conn.commit()

#def imprimirventa(valor_venta, valor_compra, Fecha):
#    INCH = 1440
#    hDC = win32ui.CreateDC()
#    hDC.CreatePrinterDC(win32print.GetDefaultPrinter())
#    hDC.StartDoc("Test doc")
#    hDC.StartPage()
#    hDC.SetMapMode(win32con.MM_TWIPS)
#    hDC.DrawText("TEST", (0, INCH * -1, INCH * 8, INCH * -2), win32con.DT_CENTER)
#    hDC.EndPage()
#    hDC.EndDoc()