$(document).ready(function(){

  //Formulario inicio index
  if($("#suscribete").length==1){
    //Mostrar tooltip
    $('[data-toggle="tooltip"]').tooltip();
  }
  //Formulario fin index

  $("#operacion").click(function() {
    var enviar = $("#enviar").val();
    var tipoMonedaEnviar = $("#tipoMonedaEnviar").text();
    var tipoMonedaRecibir = $("#tipoMonedaRecibir").text();
    var url = "/operacion"; 
    location.href=url+"/"+enviar+'-'+tipoMonedaEnviar+'-'+tipoMonedaRecibir;
  });

  //calcular dolares
  $("#enviar").change(function() {
  	enviarMonto ();
    if($("#formularioOperacion").length==1){
      getDataCuentasEmpresa();
    }
  });

  //calcular soles
  $("#recibir").change(function() {
	  recibirMonto ();
    if($("#formularioOperacion").length==1){
      getDataCuentasEmpresa();
    }
  });

  //actualizar monto 
  $("#cambio").click(function() {
  	var tipoMonedaEnviar = $("#tipoMonedaEnviar").text();
  	var tipoMonedaRecibir = $("#tipoMonedaRecibir").text();
  	$("#tipoMonedaEnviar").text(tipoMonedaRecibir);
  	$("#tipoMonedaRecibir").text(tipoMonedaEnviar);
  	enviarMonto ();
  	$("#cambioValor").val(tipoMonedaRecibir);
  });

  function enviarMonto (){
  	var enviarValor = $("#enviar").val();
  	var tipoMonedaEnviar = $("#tipoMonedaEnviar").text();
	  //calcular monto a recibir
  	var recibirValor = calcularMontoEnviar(enviarValor,tipoMonedaEnviar);
  	$("#recibir").val(recibirValor);
  }

  function cambiarCuentaDestino (){
    //seleccionamos la cuenta de la moneda a recibir - form operacion
    var tipoMonedaRecibir = $("#tipoMonedaRecibir").text();
    if ($("#numero_cuenta option").length!=0){
      var numero_cuentaOption = $("#numero_cuenta option")[0].label;
      if (numero_cuentaOption.split("-")[1]==tipoMonedaRecibir){
        $("#numero_cuenta").val($("#numero_cuenta option")[0].value);
      }
      else {
        $("#numero_cuenta").val($("#numero_cuenta option")[1].value);
      }
    }
  }

  enviarMonto ();

  function recibirMonto (){
  	var recibirValor = $("#recibir").val();
  	//obtener tipo de cambio
  	var tipoMonedaRecibir = $("#tipoMonedaRecibir").text();
	//calcular monto a recibir
  	var enviarValor = calcularMontoRecibir(recibirValor,tipoMonedaRecibir);
  	$("#enviar").val(enviarValor);
  }

  function calcularMontoEnviar(enviar, tipoMoneda) {
  	var recibirValor=0;
  	if (tipoMoneda==="Soles"){
  		//obtener tipo de cambio
  		var tipoCambio = $("#valor_venta").val();
      $("#tipoCambio").text(tipoCambio);
	  	recibirValor = (enviar / tipoCambio).toFixed(3);
  	}
  	if (tipoMoneda==="Dolares"){
  		//obtener tipo de cambio
  		var tipoCambio = $("#valor_compra").val();
      $("#tipoCambio").text(tipoCambio);
	  	recibirValor = (enviar * tipoCambio).toFixed(3);
  	}

  	return recibirValor;
  }

  function calcularMontoRecibir(recibir, tipoMoneda) {
    var recibirValor=0;
    if (tipoMoneda==="Soles"){
      //obtener tipo de cambio
      var tipoCambio = $("#valor_compra").val();
      $("#tipoCambio").text(tipoCambio);
      recibirValor = (recibir / tipoCambio).toFixed(2);
    }
    if (tipoMoneda==="Dolares"){
      //obtener tipo de cambio
      var tipoCambio = $("#valor_venta").val();
      $("#tipoCambio").text(tipoCambio);
      recibirValor = (recibir * tipoCambio).toFixed(2);
    }

    return recibirValor;
  }

  $("#banco_id").change(function() {
    $("#banco_dolar").val($("#banco_id option:selected").text());
  });

 
  function getDataCuentas(){
    $.ajax({
      type: "GET",
      url: location.origin+'/cuentasPorBanco/'+ $("#banco_id").val(), 
      dataType: "json",
      success: function(data){
        //limpiar opciones
        $("#numero_cuenta").empty(); 
        
        //no tiene cuenta registradas
        var noTieneCuenta = false;
        var alertaUsuarioSinCuenta = "hidden";
        if (data.elements.length===0){
          $("#numero_cuenta").append('<option value="">Sin Cuentas registradas</option>');
          noTieneCuenta=true;
          alertaUsuarioSinCuenta = "visible";
        }
        else {
          $.each(data.elements,function(key, cuenta){
            var selected ='';
            var moneda = getConvertirTextoMoneda(cuenta.tipoCuenta);
            if($("#tipoMonedaRecibir").text()==moneda){
              selected ='selected';
            }
           
            $("#numero_cuenta").append('<option '+selected+' value='+cuenta.cuentaId+'>'+cuenta.numeroCuenta+'-'+ moneda+'</option>');
          });
          getDataCuentasEmpresa();
        }

        $("#alertaUsuarioSinCuenta").css("visibility", alertaUsuarioSinCuenta);
        $("#btn-siguiente-operacion").attr("disabled", noTieneCuenta);

      },
      error: function(data) {
        alert('error');
      }
    });
  }
  //convertir texto de moneda
  function getConvertirTextoMoneda(moneda){
    if (moneda==="SOLES"){
      moneda = "Soles";
    }
    if (moneda==="DOLARES AMERICANOS"){
      moneda = "Dolares";
    }
    return moneda;
  } 
  //cargar cuentas de la casa de cambio
   function getDataCuentasEmpresa(){
    $.ajax({
      type: "GET",
      url: location.origin+'/cuentasEmpresa/'+ $("#banco_id").val(), 
      dataType: "json",
      success: function(data){
        if (data.elements.length===0){
          $("#alertaCasaCambioSinCuenta").css("visibility", "visible");
          $("#btn-siguiente-operacion").attr("disabled", true);
        }
        else
        {
          $.each(data.elements,function(key, cuenta){
            moneda = getConvertirTextoMoneda(cuenta.tipoCuenta);
            if($("#tipoMonedaRecibir").text()==moneda){
              //validamos si la casa de cambio cuenta con el monto minimo
              if(cuenta.monto>=Number($("#recibir").val())){
                $("#numeroCuentaBancoEmpresa").text(cuenta.numeroCuenta);
                $("#alertaCasaCambioSinFondo").css("visibility", "hidden");
              }
              else {
                $("#alertaCasaCambioSinFondo").css("visibility", "visible");
                $("#numeroCuentaBancoEmpresa").text("000000000000000000");
              }
              $("#cuenta_destino_id").val(cuenta.cuentaId);
            }
          });

          $("#alertaCasaCambioSinCuenta").css("visibility", "hidden");
          $("#btn-siguiente-operacion").attr("disabled", false);
        }
        
      },
      error: function(data) {
        alert('error');
      }
    });
  }

  //Actualizar datos de 2/3 TRANSFIERE A NUESTRA CUENTA
  function actualizarDatosBancoDestino(){
    var banco_id = $("#banco_id option:selected").text();
    $("#nombreBancoDestino").text(banco_id);
    var tipoMonedaRecibir = $("#tipoMonedaRecibir").text();
    $("#tipoCuentaBancoDestino").text(tipoMonedaRecibir);
  }

  //Formulario Operacion
  if($("#formularioOperacion").length==1){
    
    getDataCuentas();
    actualizarDatosBancoDestino();
    enviarMonto ();
    cambiarCuentaDestino();
    
    $("#banco_id").change(function() {
      getDataCuentas();
      actualizarDatosBancoDestino();
    });

    //boton actualizar monto - form operacion
    $("#cambioOperacion").click(function() {
      var tipoMonedaEnviar = $("#tipoMonedaEnviar").text();
      var tipoMonedaRecibir = $("#tipoMonedaRecibir").text();
      $("#tipoMonedaEnviar").text(tipoMonedaRecibir);
      $("#tipoMonedaRecibir").text(tipoMonedaEnviar);
      actualizarDatosBancoDestino();
      getDataCuentasEmpresa();
      enviarMonto ();
      cambiarCuentaDestino();
    });

    $("#numero_cuenta").change(function(){
      var tipoMonedaEnviar = $("#tipoMonedaEnviar").text();
      var tipoMonedaRecibir = $("#tipoMonedaRecibir").text();
      var tipoMonedaComboCuentaSelect = $("#numero_cuenta option:selected").text().split("-")[1];
      if(tipoMonedaComboCuentaSelect===tipoMonedaRecibir){

      }
      else{
         $("#tipoMonedaEnviar").text(tipoMonedaRecibir);
         $("#tipoMonedaRecibir").text(tipoMonedaEnviar);

      }
      actualizarDatosBancoDestino();
      getDataCuentasEmpresa();
      enviarMonto ();
    });
  }
  //fin form operacion

  //Formulario formularioEmpresaListado
  if($("#formularioEmpresaListado").length==1){
    
     var table = $('#example').DataTable({
        columnDefs: [{
            orderable: true,
            targets: [1,2,3]
        }],
        "scrollX": true
    });

    $("#cliente_ids").val(table.$('input, select').serialize());

    $(".cliente_id").change(function() { 
      $("#cliente_ids").val(table.$('input, select').serialize());
    });
  }
  //fin formularioEmpresaListado


});

  //validacion de contraseña inicio
  function validatePassword()
  {
    var password = document.getElementById("password");
    var confirm_password = document.getElementById("confirm_password");
    if(password.value != confirm_password.value) {
      $("#confirm_password").addClass('is-invalid');
      $("#confirm_password").removeClass('is-valid');
    } else {
      $("#confirm_password").addClass('is-valid');
    }
  }

  //validacion de contraseña fin

  //funciones de validacion inicio

  function isNumberKey(evt)
  {
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode != 46 && charCode > 31 
    && (charCode < 48 || charCode > 57))
    return false;
    return true;
  }

  function isNumericKey(evt)
  {
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode != 46 && charCode > 31 
    && (charCode < 48 || charCode > 57))
    return true;
    return false;
  }
  //funciones de validacion fin

/*
document.getElementById('iframe').scrollTop = -438;

var myIframe = document.getElementById('iframe');
myIframe.onload = function () {
    myIframe.contentWindow.scrollTo(100px,100px);
}*/


function scrollDiv(){
    var div = document.getElementById('iframe');
    div.scrollTop  = '9999';
}